from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')


@app.route("/calci", methods=["GET", "POST"])
def calculate():
    if request.method == "POST":
        try:
            a = float(request.form["A"])
            b = float(request.form["B"])
            addition = a + b
            subtraction = a - b
            multiplication = a * b
            division = a / b
            result = {
                'addition': addition,
                'subtraction': subtraction,
                'multiplication': multiplication,
                'division': division
            }
            return render_template("index.html", result=result)
        except ValueError:
            error_message = "Invalid input. Please enter numeric values."
            return render_template("index.html", error=error_message)
    else:
        return render_template("index.html")


if __name__ == '__main__':
    app.run(port=5000, debug=True)